#!/bin/bash

echo "🚀 Pushing to Netlify..."
echo ""

# Check for Netlify token
if [ -z "$NETLIFY_TOKEN" ]; then
  echo "⚠️  NETLIFY_TOKEN environment variable not set."
  echo ""
  echo "📋 Deployment Instructions:"
  echo ""
  echo "Option 1: Manual Drag & Drop (FASTEST)"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "1. Visit: https://app.netlify.com/drop"
  echo "2. Drag the 'dist' folder to the page"
  echo "3. Your site will be live instantly!"
  echo ""
  echo "Option 2: GitHub Integration (AUTO-DEPLOY)"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "1. Visit: https://app.netlify.com/start"
  echo "2. Click 'Deploy with GitHub'"
  echo "3. Select: always-payment-system"
  echo "4. Build settings:"
  echo "   - Build command: npm run build"
  echo "   - Publish directory: dist"
  echo "5. Click 'Deploy site'"
  echo ""
  echo "Option 3: API Deployment (requires token)"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "1. Get token: https://app.netlify.com/user/applications#personal-access-tokens"
  echo "2. Export: export NETLIFY_TOKEN=your_token"
  echo "3. Run: ./push_to_netlify.sh"
  echo ""
else
  echo "✅ Netlify token found!"
  echo ""
  
  # Try to create a new site or deploy
  echo "📦 Preparing deployment..."
  
  # Create zip package
  cd dist
  zip -r ../netlify-deploy.zip . > /dev/null 2>&1
  cd ..
  
  echo "✅ Package created: netlify-deploy.zip"
  echo ""
  
  # Try to list sites
  echo "🔍 Checking existing sites..."
  SITES=$(curl -s -H "Authorization: Bearer $NETLIFY_TOKEN" \
    "https://api.netlify.com/api/v1/sites" 2>/dev/null)
  
  SITE_COUNT=$(echo "$SITES" | grep -o '"id"' | wc -l)
  
  if [ "$SITE_COUNT" -gt 0 ]; then
    echo "📍 Found $SITE_COUNT site(s)"
    SITE_ID=$(echo "$SITES" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)
    echo "Using site ID: $SITE_ID"
    echo ""
    
    # Deploy to existing site
    echo "🚀 Deploying to Netlify..."
    RESPONSE=$(curl -s -X POST \
      -H "Authorization: Bearer $NETLIFY_TOKEN" \
      -H "Content-Type: application/zip" \
      --data-binary "@netlify-deploy.zip" \
      "https://api.netlify.com/api/v1/sites/$SITE_ID/deploys" 2>/dev/null)
    
    DEPLOY_URL=$(echo "$RESPONSE" | grep -o '"deploy_url":"[^"]*"' | cut -d'"' -f4)
    DEPLOY_STATE=$(echo "$RESPONSE" | grep -o '"state":"[^"]*"' | cut -d'"' -f4)
    
    if [ ! -z "$DEPLOY_URL" ]; then
      echo "✅ Deployment successful!"
      echo ""
      echo "🌐 Your site is live:"
      echo "   $DEPLOY_URL"
      echo ""
      echo "📊 Status: $DEPLOY_STATE"
    else
      echo "❌ Deployment failed"
      echo "Response: $RESPONSE"
    fi
  else
    echo "⚠️  No sites found. Creating new site..."
    
    # Try to create a new site
    RESPONSE=$(curl -s -X POST \
      -H "Authorization: Bearer $NETLIFY_TOKEN" \
      -H "Content-Type: application/json" \
      -d '{"name":"always-payment-dynamic-links"}' \
      "https://api.netlify.com/api/v1/sites" 2>/dev/null)
    
    SITE_ID=$(echo "$RESPONSE" | grep -o '"id":"[^"]*"' | cut -d'"' -f4)
    
    if [ ! -z "$SITE_ID" ]; then
      echo "✅ Site created: $SITE_ID"
      echo ""
      echo "🚀 Deploying..."
      
      DEPLOY_RESP=$(curl -s -X POST \
        -H "Authorization: Bearer $NETLIFY_TOKEN" \
        -H "Content-Type: application/zip" \
        --data-binary "@netlify-deploy.zip" \
        "https://api.netlify.com/api/v1/sites/$SITE_ID/deploys" 2>/dev/null)
      
      DEPLOY_URL=$(echo "$DEPLOY_RESP" | grep -o '"deploy_url":"[^"]*"' | cut -d'"' -f4)
      
      if [ ! -z "$DEPLOY_URL" ]; then
        echo "✅ Deployment successful!"
        echo ""
        echo "🌐 Your site is live:"
        echo "   $DEPLOY_URL"
      fi
    else
      echo "❌ Failed to create site"
    fi
  fi
  
  # Clean up
  rm -f netlify-deploy.zip
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Deployment package ready in dist/ folder"
echo "📝 Manual deploy at: https://app.netlify.com/drop"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

